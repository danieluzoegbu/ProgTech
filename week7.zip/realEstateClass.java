import java.util.logging.Logger;

/**
 * Represents a general real estate property.
 */
public class RealEstate implements PropertyInterface {
    private static final Logger LOGGER = LoggerConfig.getLogger();

    protected String city;
    protected double price;
    protected int sqm;
    protected double numberOfRooms;
    protected Genre genre;

    /**
     * Constructs a RealEstate object.
     *
     * @param city          the city where the property is located
     * @param price         the price per square meter
     * @param sqm           the size of the property in square meters
     * @param numberOfRooms the number of rooms in the property
     * @param genre         the genre/type of the property
     */
    public RealEstate(String city, double price, int sqm, double numberOfRooms, Genre genre) {
        LOGGER.info("RealEstate constructor called.");
        this.city = city;
        this.price = price;
        this.sqm = sqm;
        this.numberOfRooms = numberOfRooms;
        this.genre = genre;
    }

    /**
     * Applies a discount to the price per square meter.
     *
     * @param percentage the percentage of the discount
     */
    @Override
    public void makeDiscount(int percentage) {
        LOGGER.info("makeDiscount called with percentage: " + percentage);
        price -= price * percentage / 100.0;
    }

    /**
     * Calculates the total price of the property.
     * City modifiers are applied to the base price.
     *
     * @return the total price of the property
     */
    @Override
    public int getTotalPrice() {
        LOGGER.info("getTotalPrice called.");
        double totalPrice = price * sqm;
        if (city.equalsIgnoreCase("Budapest")) totalPrice *= 1.3;
        else if (city.equalsIgnoreCase("Debrecen")) totalPrice *= 1.2;
        else if (city.equalsIgnoreCase("Nyíregyháza")) totalPrice *= 1.15;
        return (int) totalPrice;
    }

    /**
     * Calculates the average square meters per room.
     *
     * @return the average square meters per room
     */
    @Override
    public double averageSqmPerRoom() {
        LOGGER.info("averageSqmPerRoom called.");
        return sqm / numberOfRooms;
    }

    /**
     * Returns a string representation of the RealEstate object.
     *
     * @return a string containing the property details
     */
    @Override
    public String toString() {
        LOGGER.info("toString called.");
        return String.format("City: %s, Price: %.2f, Sqm: %d, Rooms: %.1f, Genre: %s, TotalPrice: %d, AvgSqmPerRoom: %.2f",
                city, price, sqm, numberOfRooms, genre, getTotalPrice(), averageSqmPerRoom());
    }
}

