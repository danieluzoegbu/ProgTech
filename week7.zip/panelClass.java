/**
 * Represents a panel-type property that extends RealEstate.
 */
public class Panel extends RealEstate implements PanelInterface {
    private static final Logger LOGGER = LoggerConfig.getLogger();

    private int floor;
    private boolean isInsulated;

    /**
     * Constructs a Panel object.
     *
     * @param city          the city where the property is located
     * @param price         the price per square meter
     * @param sqm           the size of the property in square meters
     * @param numberOfRooms the number of rooms in the property
     * @param genre         the genre/type of the property
     * @param floor         the floor the property is located on
     * @param isInsulated   whether the property has external insulation
     */
    public Panel(String city, double price, int sqm, double numberOfRooms, Genre genre, int floor, boolean isInsulated) {
        super(city, price, sqm, numberOfRooms, genre);
        LOGGER.info("Panel constructor called.");
        this.floor = floor;
        this.isInsulated = isInsulated;
    }

    /**
     * Calculates the total price of the panel property.
     * Additional modifiers are applied based on the floor and insulation.
     *
     * @return the total price of the panel property
     */
    @Override
    public int getTotalPrice() {
        LOGGER.info("Panel getTotalPrice called.");
        double totalPrice = super.getTotalPrice();
        if (floor >= 0 && floor <= 2) totalPrice *= 1.05;
        if (floor == 10) totalPrice *= 0.95;
        if (isInsulated) totalPrice *= 1.05;
        return (int) totalPrice;
    }

    /**
     * Checks if another RealEstate object has the same total price.
     *
     * @param other the other RealEstate object
     * @return true if the total prices are the same, false otherwise
     */
    @Override
    public boolean hasSameAmount(RealEstate other) {
        LOGGER.info("hasSameAmount called.");
        return this.getTotalPrice() == other.getTotalPrice();
    }

    /**
     * Calculates the average cost of a room in the panel property.
     *
     * @return the average room cost
     */
    @Override
    public int roomPrice() {
        LOGGER.info("roomPrice called.");
        return (int) (price * sqm / numberOfRooms);
    }

    /**
     * Returns a string representation of the Panel object.
     *
     * @return a string containing the panel property details
     */
    @Override
    public String toString() {
        LOGGER.info("Panel toString called.");
        return super.toString() + String.format(", Floor: %d, Insulated: %b", floor, isInsulated);
    }
}

